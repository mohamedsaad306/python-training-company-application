"""Test deprecated modules."""

from deprecated import foo  # [deprecated-module]
import deprecated  # [deprecated-module]
